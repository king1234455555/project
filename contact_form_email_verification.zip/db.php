<?php
$connect = new mysqli("localhost", "root", "", "contact_form");
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}
?>