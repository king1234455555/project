<?php
session_start();
include "db.php";
require "mailer/PHPMailer.php";
require "mailer/SMTP.php";
require "mailer/Exception.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (isset($_POST['submit'])) {
    $name    = $_POST['name'];
    $email   = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    $token   = md5(rand());

    $stmt = $connect->prepare("INSERT INTO contacts (name, email, subject, message, token) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $subject, $message, $token);
    $stmt->execute();

    $verify_link = "http://localhost/contact_form/verify.php?email=$email&token=$token";

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'your_email@gmail.com';
        $mail->Password   = 'your_email_app_password';
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        $mail->setFrom('your_email@gmail.com', 'Contact Form');
        $mail->addAddress($email, $name);

        $mail->isHTML(true);
        $mail->Subject = "Email Verification";
        $mail->Body    = "Hi $name,<br>Please verify your email by clicking the link below:<br><a href='$verify_link'>$verify_link</a>";

        $mail->send();
        echo "Verification link sent to $email. Please check your inbox.";
    } catch (Exception $e) {
        echo "Mailer Error: {$mail->ErrorInfo}";
    }
}
?>