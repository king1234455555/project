<?php
include "db.php";

if (isset($_GET['email']) && isset($_GET['token'])) {
    $email = $_GET['email'];
    $token = $_GET['token'];

    $check = $connect->query("SELECT * FROM contacts WHERE email='$email' AND token='$token' AND verified=0");

    if ($check->num_rows > 0) {
        $connect->query("UPDATE contacts SET verified=1 WHERE email='$email'");
        echo "Email verified successfully. Your message is submitted.";
    } else {
        echo "Invalid or already verified.";
    }
}
?>